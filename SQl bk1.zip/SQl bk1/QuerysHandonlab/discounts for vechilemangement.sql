alter procedure udp_proc_check_vechicle_discounts
				@VehicleType varchar(10),@Location varchar(10),@customerid int,@discount int output
				as
				begin
				declare @count int
				-- select b.Customer_id,v.vehicletype,v.location from tbl_Vehicle_Details  v inner join tbl_Vehicle_Booking  b on v.location=b.location where vehicletype='ford' and location=4 -- vehicletype=@VehicleType and location=@Location 
								select @count=(select count(Customer_id) from tbl_Vehicle_Booking where vehicletype=@VehicleType and location=@Location and  customer_id=@customerid group by Customer_id)
								 
								if(@count>=1)
								select  @discount=Discount from tbl_Vehicle_Discounts where vehicletype=@VehicleType and location=@Location
								--print '@typevehicle'
								else
								set @discount=0
				end
				declare @discount int
				exec udp_proc_check_vechicle_discounts 'swift','2',101,@discount out
				print @discount