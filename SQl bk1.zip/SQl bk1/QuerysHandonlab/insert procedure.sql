create PROCEDURE proc_insert_vehicle_booking (@Customer_Id Varchar(10),@VehicleType Varchar(10),@TravelType Varchar(10),
  @Address Varchar(10),@Location Varchar(3),@DateOfBooking DateTime,@JourneyStartDate	DateTime,@JourneyStartTime	Decimal(4,2),
  @JourneyEndDate DateTime,@JourneyEndTime Decimal(4,2),@out_status int out,@out_booking_id int out)
AS
BEGIN
	declare  @EndDate DATETIME,@booking_id int,@days int
	select  @EndDate=min(JourneyEndDate) from tbl_Vehicle_Booking where  VehicleType=@VehicleType and Location=@Location GROUP BY  VehicleType
	
	if(@EndDate < @JourneyStartDate)
	begin
		set @out_status=1
		insert tbl_Vehicle_Booking values(@Customer_Id,@VehicleType,@TravelType,@Address,@Location,@DateOfBooking,@JourneyStartDate,@JourneyStartTime,@JourneyEndDate,@JourneyEndTime)
		select top 1 @booking_id=booking_id from tbl_Vehicle_Booking Order by booking_id desc
		set @out_booking_id=@booking_id
		end
		ELSE
		begin
		set @out_status=0
		set @out_booking_id=0
		end

END
GO

declare  @out_status int,@out_booking_id int
exec proc_insert_vehicle_booking 101,'innova','travel','trichy','3','11/29/2019','12/01/2019',13.00,'12/02/2019',17.00,@out_status out,@out_booking_id out
print @out_status
print @out_booking_id
