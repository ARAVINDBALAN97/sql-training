use DB_Nov_Batch

select * from tbl_trainees


select * from tbl_trainees where college = (select college  from tbl_trainees where name='dhivya')and domain = (select domain from  tbl_trainees where name='dhivya' )

select * from tbl_trainees where percentage < any (select percentage from tbl_trainees where domain = 'ECE')
 --select percentage,domain from tbl_taineees o
where percentage>(select AVG (percentage) from tbl_trainees d where o.domain=d.domain);

select * from tbl_trainees where percentage < (select avg (percentage) from tbl_trainees where domain=domain)
select avg(percentage ) cse from tbl_trainees where domain ='cse'