
create table tbl_City (CityCode	Varchar(3) PRIMARY KEY ,CityName Varchar(50)UNIQUE);
create table tbl_Customer(CustomerId Int PRIMARY KEY identity(100,1) ,FirstName	Varchar(50)NOT NULL,LastName Varchar(50)NOT NULL,
Address	Varchar(50)NOT NULL,Email Varchar(50) UNIQUE NOT NULL,Phone varchar(10)NOT NULL)
create table tbl_Vehicle_Details (
VehicleType	Varchar(10),	
Location	Varchar(3)Foreign key REFERENCES tbl_City(CityCode),
NoOfVehicles	Int	check(NoOfVehicles>0),
RatePerDay	Int	check(RatePerDay>0),
Tax	Decimal(4,2)	,
Primary Key(VehicleType,Location))

create table tbl_Vehicle_Booking 
(BookingId	Int	Primary Key Identity(200,1),
CustomerId	Int	FOREIGN KEY REFERENCES tbl_Customer(CustomerId),
VehicleType	Varchar(10)	,
TravelType	Varchar(10)	check(TravelType IN('Travel','Day','Drop'))
,Address	Varchar(30),	
Location	Varchar(3)	FOREIGN KEY REFERENCES tbl_City(CityCode),
DateOfBooking	DateTime NOT NULL,	
JourneyStartDate	DateTime	NOT NULL,
JourneyStartTime	Decimal(4,2),	
JourneyEndDate	DateTime	NOT NULL,
JourneyEndTime	Decimal(4,2) NOT NULL,	
check(JourneyStartDate>=DateOfBooking),check(JourneyEndDate>=JourneyStartDate),
constraint fk_key1 FOREIGN Key(VehicleType,Location) REFERENCES tbl_Vehicle_Details(VehicleType,Location))

create table tbl_Customer_Discounts(BookingId Int	FOREIGN KEY REFERENCES tbl_Vehicle_Booking(BookingId),
CustomerId	Int	FOREIGN KEY REFERENCES tbl_Customer(CustomerId),
DateOfAvailing	DateTime	
)

create table  tbl_Vehicle_Discounts(VehicleType	Varchar(10)	,
Location	Varchar(3)	,
NoOfTimes	Int	,
Discount	Decimal(4,2),	
constraint fk_key2 FOREIGN Key(VehicleType,Location) REFERENCES tbl_Vehicle_Details(VehicleType,Location))

create table tbl_Vehicle_Payment(PaymentId	Varchar(4)	Primary Key,
BookingId	Int	FOREIGN KEY REFERENCES tbl_Vehicle_Booking(BookingId),
TotalCharges	Int	,
TotalTaxAmount	Decimal(7,2),	
DiscountAvailable	tinyint	check(DiscountAvailable IN(0,1))