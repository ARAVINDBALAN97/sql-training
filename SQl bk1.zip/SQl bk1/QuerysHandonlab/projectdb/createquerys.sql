create database EP_SkillMatrix
use EP_SkillMatrix


create schema t_user

drop schema t_user
create table tbl_user(userid int constraint pk_tbl_user_userid primary key,
username varchar(20)not null,
password varchar(20)not null,
DOB datetime not null,email varchar(20))

create table tbl_role(roleid int constraint pk_tbl_role_roleid primary key,
rollname varchar(20)not null,
roledescription varchar (40) not null)

create table tbl_userrole (userroleid int constraint pk_tbl_user_role_userroleid primary key 
,userid int constraint fk_tbl_userrole_userid foreign key references tbl_user(userid),
roleid int constraint fk_tbl_userrole_roleid foreign key references tbl_role(roleid))

create table tbl_category (categoryid int constraint _pk_tbl_category primary key not null
,categoryname varchar (20)not null,
categorydescription varchar(40)not null)

create table tbl_user(userid int constraint pk_tbl_user_userid primary key,username varchar(20)not null,
password varchar(20)not null,
DOB datetime not null,
email varchar(20))

create table tbl_role(roleid int constraint pk_tbl_role_roleid primary key not null,
rollname varchar(20)not null,
roledescription varchar (40)not null)

create table tbl_userrole (userroleid int constraint pk_tbl_user_role_userroleid primary key not null,
userid int constraint fk_tbl_userrole_userid foreign key references tbl_user(userid),
roleid int constraint fk_tbl_userrole_roleid foreign key references tbl_role(roleid))

create table tbl_category (categoryid int constraint _pk_tbl_category primary key not null,
categoryname varchar (20)not null,
categorydescription varchar(40)not null)

create table tbl_skill (skillid int constraint _pk_tbl_skill primary key not null,
skillname varchar(20)not null,
categoryid int constraint fk_tbl_skill_categoryid foreign key references tbl_category(categoryid))

create table tbl_score (scoreid tinyint constraint ck_tbl_score check(scoreid between 0 and 5) ,
description varchar(20)not null,detaileddescription varchar(30) not null)

create table tbl_employee ( empid int constraint _pk_tbl_employee primary key,
employeename varchar(20)not null)

create table tbl_result (employeeid int constraint _pk_tbl_result primary key,
categoryid int constraint fk_tbl_result_categoryid foreign key references tbl_category(categoryid),
skillid int constraint fk_tbl_result_skillid foreign key references tbl_skill(skillid),
empscore int constraint fk_tbl_result_empscore  foreign key references tbl_score(scoreid),
interest int  not null)