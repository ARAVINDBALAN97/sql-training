use dharman
merge into tbl_Trainees_Target t using tbl_trainees s
on (t.id=s.id)
when matched then update set t.name=s.name,t.domain=s.domain,t.college=s.college,t.percentage=s.percentage,t.technology=s.technology
when not matched by target then insert values(s.id,s.name,s.domain,s.college,s.percentage,s.technology)
when not matched by source then delete;