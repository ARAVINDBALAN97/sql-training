USE FLIGHT_MANAGEMENT
SELECT * FROM TBL_FLIGHT
select * from tbl_flight_booking
UPDATE TBL_FLIGHT SET TOTAL_SEATS=500 WHERE FLIGHT_NO IN(506,507,508)



select sum(cast( b.total_seats_booking as int )) as total from tbl_flight f join tbl_flight_booking b on f.flight_no = b.flight_no where f.flight_no = 506 group by f.flight_no 
SELECT Total_seats FROM TBL_FLIGHT where flight_no = 506
select * from tbl_flight_booking 

Select *,case 
when flight_no between 504 and 507 then 'yes'
else 'fail'
end 'total' from TBL_FLIGHT


alter  proc usp2_proc_insert_flight_booking( 
@Flight_No int,@customerid int,@Date_Of_Booking datetime,
@Date_Of_Journey datetime,@No_Of_Adults int,@No_Of_Children int,@total_seats_booking varchar(10),
@result int out)
as
begin
declare @seats int
declare @Flight_seats int
declare @Available_seats int

select @seats =(select sum(cast( b.total_seats_booking as int )) as
total from tbl_flight f join tbl_flight_booking b on f.flight_no = b.flight_no where f.flight_no = @flight_no group by f.flight_no)
select @Flight_seats=(SELECT Total_seats FROM TBL_FLIGHT where flight_no = @flight_no)
set @Available_seats = @Flight_seats -   @seats
if(@Available_seats > 0)
set @result=0
else
 insert  tbl_flight_booking values(@Flight_No,@customerid,@Date_Of_Booking,
@Date_Of_Journey ,@No_Of_Adults ,@No_Of_Children,@total_seats_booking)
set @result= 1
end 



declare @result int
exec proc_insert_flight_booking 506,101,'12/11/2019','12/14/2019',2,3,'5', @result out
print @result


