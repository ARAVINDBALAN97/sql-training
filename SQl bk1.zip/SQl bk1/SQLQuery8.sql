use dharman

create table tbl_trigger_example(
id int not null,name varchar (10),gender varchar (10)
)

insert tbl_trigger_example values(4,'Sadham','Male')
select * from tbl_trigger_example

create trigger trg_exam_update on tbl_trigger_example
after update
as
begin
select * from inserted
select * from deleted
end
select * from tbl_trigger_example
update tbl_trigger_example set name='Ashok' where id=2
delete from tbl_trigger_example where id=3