select * from tbl_flight
select * from tbl_flight_booking
select * from total_seatsonflight


create function fn_check_Seat_Availabilty(@flight_no int,@date_of_journey datetime,@no_of_adults int,@no_of_children int)
returns  int
as
begin
declare @resultseat int
declare @totalseatsinflight int
declare @totalseatsinflightbooked int
declare @totalavailableflight int
select @totalseatsinflight=(select total_seats from tbl_flight where flight_no=@flight_no)
select @totalseatsinflightbooked=(select count(Total_seats_Booking) as total from tbl_flight_booking where flight_no=507)
set @totalavailableflight=@totalseatsinflight-@totalseatsinflightbooked
return  @totalavailableflight


end