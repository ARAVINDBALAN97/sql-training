drop proc usp_calculate_flight_payment
create proc usp8_calculate_flight_payment @in_Flight_Booking_id int,
@out_Adult_Charges int out, @out_Child_Charges int out,
@out_total_tax_amount decimal out 
as 
begin
select  @out_Adult_Charges=(b.adult_fare)*a.no_of_adults from tbl_flight_booking a join tbl_flight b on a.flight_no=b.flight_no where booking_id=@in_Flight_Booking_id;
select @out_Child_Charges=(b.child_fare)*a.no_of_children from tbl_flight_booking a join tbl_flight b on a.flight_no=b.flight_no where booking_id=@in_Flight_Booking_id;
set @out_total_tax_amount=@out_Adult_Charges + @out_Child_Charges;
end

declare @result int,@result1 int,@result2 decimal
exec usp8_calculate_flight_payment '111',@result out,@result1 out,@result2 out
print @result
print @result1
print @result2








 Create trigger ust_Flight_booking_update on tbl_flight_booking
 after update 
 as begin
 declare @total_seats_booking int,@Current_Avbl_seats int, @New_avbl_seats int,@flight_no int,@date_of_journey datetime,@total_seats_booking_del int
  select @total_seats_booking=total_seats_booking,@flight_no=flight_no from inserted 
  select @total_seats_booking_del=total_seats_booking,@flight_no=flight_no from deleted

-- select @total_seats_booked =(select sum(cast( total_seats_booking as int )) as total from  tbl_flight_booking where flight_no=@flight_no)
 select @Current_Avbl_seats =( select Remainingseats from tbl_FlightSeat_Status where flightno=@flight_no)
 --select @Totalseats_capacity=(SELECT Total_seats FROM TBL_FLIGHT where flight_no = @flight_no)
 set @New_avbl_seats=(@Current_Avbl_seats+@total_seats_booking_del)-@total_seats_booking
 update tbl_FlightSeat_Status set Remainingseats =@New_avbl_seats where flightno = @flight_no  
 end

 create trigger ust_Flight_booking on tbl_flight_booking
 after insert 
 as begin
 declare @total_seats_booking int,@Current_Avbl_seats int, @New_avbl_seats int,@flight_no int

  select @total_seats_booking=total_seats_booking,@flight_no=flight_no from inserted 

-- select @total_seats_booked =(select sum(cast( total_seats_booking as int )) as total from  tbl_flight_booking where flight_no=@flight_no)
 select @Current_Avbl_seats =( select Remainingseats from tbl_FlightSeat_Status where flightno=@flight_no)
 --select @Totalseats_capacity=(SELECT Total_seats FROM TBL_FLIGHT where flight_no = @flight_no)
 set @New_avbl_seats=@Current_Avbl_seats-@total_seats_booking
 update tbl_FlightSeat_Status set Remainingseats =@New_avbl_seats where flightno = @flight_no
 end

 create trigger ust_Flight_booking on tbl_flight_booking
 after delete 
 as begin
 declare @total_seats_booking int,@Current_Avbl_seats int, @New_avbl_seats int,@flight_no int

  select @total_seats_booking=total_seats_booking,@flight_no=flight_no from deleted 

-- select @total_seats_booked =(select sum(cast( total_seats_booking as int )) as total from  tbl_flight_booking where flight_no=@flight_no)
 select @Current_Avbl_seats =( select Remainingseats from tbl_FlightSeat_Status where flightno=@flight_no)
 --select @Totalseats_capacity=(SELECT Total_seats FROM TBL_FLIGHT where flight_no = @flight_no)
 set @New_avbl_seats=@Current_Avbl_seats+@total_seats_booking
 update tbl_FlightSeat_Status set Remainingseats =@New_avbl_seats where flightno = @flight_no
 end