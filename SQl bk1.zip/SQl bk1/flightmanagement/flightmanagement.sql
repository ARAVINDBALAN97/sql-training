USE DHARMAN
create table tbl_flight(
Flightno int constraint pk_tbl_flight_Flightno primary key identity  (500,1),
AirlinesName varchar(50),
Sourcrofflight varchar (20),
Destination varchar (20),
DepatureTime time,
Arrrivaltime time ,
TotalSeats int,
AdultFare int,
ChildFare int,
Airporttax int,
)
drop table tbl_flight

SELECT * FROM tbl_flight
insert tbl_flight (AirlinesName,Sourcrofflight,Destination,DepatureTime,Arrrivaltime,TotalSeats,AdultFare,ChildFare,Airporttax) values ('Indigo','Kolkata','Mumbai','09:00','10:30',200,3500,1000,450.00)
insert tbl_flight (AirlinesName,Sourcrofflight,Destination,DepatureTime,Arrrivaltime,TotalSeats,AdultFare,ChildFare,Airporttax) values ('SpiceJet','Andrapradesh','Kochi','11:00','12:30',100,1850,900,650.00)
insert tbl_flight (AirlinesName,Sourcrofflight,Destination,DepatureTime,Arrrivaltime,TotalSeats,AdultFare,ChildFare,Airporttax) values ('KingFisher','Bangalore','Mumbai','09:00','11:30',120,3500,1500,250.00)
insert tbl_flight (AirlinesName,Sourcrofflight,Destination,DepatureTime,Arrrivaltime,TotalSeats,AdultFare,ChildFare,Airporttax) values ('Indigo','Kolkata','Mumbai','09:00','10:30',200,3500,1000,450.00)
--------------------------------------------------------------------
create table tbl_flight_booking(
Bookingid int constraint pk_tbl_flight_booking_Bookingid primary key identity (100,1),
FlightNo int constraint fk_tbl_flight_booking_FlightNo foreign key references tbl_flight(Flightno) on update cascade,
CustomerID int UNIQUE NOT NULL,
DateofBooking datetime default getdate(),  
DateofJourney datetime NOT NULL,
NoofAdults int  NOT NULL,
NoofChilderns int,
Total_no_Seats int NOT NULL ,
Constraint Ck_Check_Doj check(Dateofjourney>=DateofBooking)
)
 
 drop table tbl_flight_booking

 INSERT INTO tbl_flight_booking ()


-------------------------------------------------------------------
Create table tbl_flight_seat_status(
flightno int  constraint fk_tbl_flight_seat_status_flightno foreign key references tbl_flight(Flightno)  on update cascade,
DateofJourney datetime NOT NULL,
Avaliableseats int,
CONSTRAINT ck_availseat_tbl_flight_seat_status check(Avaliableseats>=0))

drop table tbl_flight_seat_status

----------------------------------------------------------------------
create table tbl_Flight_Travellers(
Bookingid int constraint fk_tbl_Flight_Travellers_Bookingid foreign key references tbl_flight_booking (Bookingid) on update cascade,
FirstName varchar (20),
Lastname varchar (20),
Travellertype char(1))

drop table tbl_Flight_Travellers
-------------------------------------------------------------------
create table tbl_Flight_Payment(Paymentid int constraint pk_tbl_Flight_Payment_Paymentid primary key,
Bookingid int constraint fk_tbl_Flight_Payment_Bookingid foreign key references tbl_flight_booking (Bookingid)  on update cascade,
AdultCharges int  not null,
ChildCharges int ,
Taxamount INT not null)

drop table tbl_Flight_Payment