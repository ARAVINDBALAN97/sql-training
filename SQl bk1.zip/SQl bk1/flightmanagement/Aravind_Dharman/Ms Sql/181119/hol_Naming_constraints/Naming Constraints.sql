use Dharman



create table tbl_name_constraints(
id int constraint  pk_tbl_name_constraints_id primary key ,
name varchar (20),
)

select * from tbl_name_constraints

alter table tbl_name_constraints alter column name varchar (20) not null
sp_RENAME 'tbl_refer_foreignkey.Deptid' ,'Referid','column'

create table tbl_refer_foreignkey(
id int constraint  pk_tbl_refer_foreignkey_id primary key,
Department varchar (20) not null,
Deptid int  constraint fk_tbl_refer_foreignkey_deptid foreign key (Deptid)  references tbl_name_constraints (Deptid),
)

select * from tbl_refer_foreignkey
