use Dharman 
create table tbl_projects(
Projectid int constraint pk_tbl_projects_Projectid primary key,
ProjectName varchar (50) not null,
ProjectDomain varchar (20) not null,
)
create table tbl_developer(
Developerid int constraint pk_tbl_developer_Developerid primary key,
DeveloperName varchar (20) not null,
Designation varchar (30) not null,
Projectid int constraint fk_tbl_developer_projectid foreign key  (Projectid) references  tbl_projects (Projectid) on delete cascade
)

alter table tbl_developer 

select * from tbl_projects
select * from tbl_developer
insert into tbl_projects values (2114,'Azure','Dotnet') 
insert into tbl_projects values (2115,'AWS','JAVA')
insert into tbl_projects values (2116,'DATABASE','Mssql')
insert into tbl_projects values (2117,'Automation','Python')
insert into tbl_projects values (2118,'Webapp','php')

drop table tbl_projects

insert into tbl_developer values(33321,'Praveen','Testing',2117)
insert into tbl_developer values(33320,'Dharma','Junior Dotnet developer',2114)
insert into tbl_developer values(33319,'Harish',' Junior Java Developer',2115)
insert into tbl_developer values(33318,'Aravind','Data Analyst',2116)
insert into tbl_developer values(33317,'Aamir',' Associate Dotnet developer',2118)


select * from tbl_projects
select * from tbl_developer


delete from tbl_projects where projectid =2114


create schema tbl_workers

create table tbl_workers.tbl_wrk(
Projectid int constraint pk_tbl_wrk_Projectid primary key,
ProjectName varchar (50) not null,
ProjectDomain varchar (20) not null,
)