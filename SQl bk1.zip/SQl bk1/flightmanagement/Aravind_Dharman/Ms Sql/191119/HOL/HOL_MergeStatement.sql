use dharman 

create table tbl_collegestudents(
Studentid int constraint pk_tbl_college_studentid primary key,
StudentName varchar (50) not null,
Class varchar (20) not null,
Dateofbirth date not null,
Mobile nvarchar not null 
)
DROP TABLE tbl_collegestudents
ALTER TABLE tbl_collegestudents ALTER COLUMN MOBILE NVARCHAR(20) NOT NULL
select * from tbl_collegestudents
insert tbl_collegestudents values(14,'SIVA','IV','4/8/1990','1234567872')

CREATE TABLE tbl_collegestudents_target as select * from tbl_collegestudents
select * into  tbl_collegestudents_target from tbl_collegestudents
select * from tbl_collegestudents_target
select * from tbl_collegestudents

merge into tbl_collegestudents_target t using tbl_collegestudents s on t.Studentid=s.Studentid
when matched then update set t.StudentName=s.StudentName,t.Class=s.Class,t.Dateofbirth=s.Dateofbirth, t.Mobile=s.Mobile
when not matched by target then insert values(s.Studentid,s.StudentName,s.Class,s.Dateofbirth,s.Mobile)
when not matched by source then delete;


delete from tbl_collegestudents where Studentid=11
update tbl_collegestudents set StudentName='ameer' where Studentid=12

insert tbl_collegestudents values (23,'Harish','IV','12/03/1996','965689658')



