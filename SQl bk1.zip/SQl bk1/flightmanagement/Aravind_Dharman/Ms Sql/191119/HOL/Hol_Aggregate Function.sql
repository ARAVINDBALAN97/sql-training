use dharman 
CREATE TABLE TBL_TEAMS 
( TEAM_ID        INT    NOT NULL,
  NAME        VARCHAR(20)    NOT NULL );
CREATE TABLE TBL_PLAYERS 
( PLAYER_ID     INT    NOT NULL,
  LAST        VARCHAR(20)    NOT NULL,
  FIRST        VARCHAR(20)    NOT NULL,
  TEAM_ID        INT    NULL,
  NUMBER        INT    NOT NULL );
  CREATE TABLE TBL_PLAYER_DATA 
( PLAYER_ID    INT    NOT NULL,
  HEIGTH        DECIMAL(4,2)    NOT NULL,
  WEIGHT        DECIMAL(5,2)    NOT NULL );
CREATE TABLE TBL_GAMES 
( GAME_ID            INT    NOT NULL,
  GAME_DT            DATETIME        NOT NULL,
  HOME_TEAM_ID        INT    NOT NULL,
  GUEST_TEAM_ID    INT   NOT NULL );
CREATE TABLE TBl_SCORES 
( GAME_ID        INT    NOT NULL,
  TEAM_ID        INT    NOT NULL,
  SCORE        INT   NOT NULL,
  WIN_LOSE    VARCHAR(4)    NOT NULL );

  select * from TBL_TEAMS
  select * from TBL_PLAYERS
  select * from TBL_PLAYER_DATA
  select * from TBL_GAMES
  select * from TBl_SCORES

TRUNCATE TABLE TBl_SCORES
SELECT TEAM_ID FROM SCORES GROUP BY TEAM_ID ORDER BY AVG(SCORE) DESC LIMIT 1;
select max(score) from scores 
SELECT AVG(SCORE) FROM SCORES GROUP BY GAME_ID ORDER BY AVG(SCORE)  DESC LIMIT 1

---TBL_TEAMS Datas
INSERT INTO TBL_TEAMS VALUES ('1','STRING MUSIC'); 
INSERT INTO TBL_TEAMS VALUES ('2','HACKERS');
INSERT INTO TBL_TEAMS VALUES ('3','SHARP SHOOTERS');
INSERT INTO TBL_TEAMS VALUES ('4','HAMMER TIME');
truncate table TBL_TEAMS
---TBL_PLAYERS Datas
INSERT INTO TBL_PLAYERS VALUES ('1','SMITH','JOHN','1','12'); 
INSERT INTO TBL_PLAYERS VALUES ('2','BOBBIT','BILLY','1','2');
INSERT INTO TBL_PLAYERS VALUES ('3','HURTA','WIL','2','32');
INSERT INTO TBL_PLAYERS VALUES ('4','OUCHY','TIM','2','22');
INSERT INTO TBL_PLAYERS VALUES ('5','BYRD','ERIC','3','6');
INSERT INTO TBL_PLAYERS VALUES ('6','JORDAN','RYAN','3','23');
INSERT INTO TBL_PLAYERS VALUES ('7','HAMMER','WALLY','4','21');
INSERT INTO TBL_PLAYERS VALUES ('8','HAMMER','RON','4','44');
INSERT INTO TBL_PLAYERS VALUES ('11','KNOTGOOD','AL',NULL,'0');
---TBL_PLAYER_DATA Datas
INSERT INTO TBL_PLAYER_DATA VALUES ('1','71','180'); 
INSERT INTO TBL_PLAYER_DATA VALUES ('2','58','195');
INSERT INTO TBL_PLAYER_DATA VALUES ('3','72','200');
INSERT INTO TBL_PLAYER_DATA VALUES ('4','74','170');
INSERT INTO TBL_PLAYER_DATA VALUES ('5','71','182');
INSERT INTO TBL_PLAYER_DATA VALUES ('6','72','289');
INSERT INTO TBL_PLAYER_DATA VALUES ('7','79','250');
INSERT INTO TBL_PLAYER_DATA VALUES ('8','73','193');
INSERT INTO TBL_PLAYER_DATA VALUES ('11','85','310');
---TBL_GAMES Datas
INSERT INTO TBL_GAMES VALUES ('1','2002-05-01','1','2'); 
INSERT INTO TBL_GAMES VALUES ('2','2002-05-02','3','4');
INSERT INTO TBL_GAMES VALUES ('3','2002-05-03','1','3');
INSERT INTO TBL_GAMES VALUES ('4','2002-05-05','2','4');
INSERT INTO TBL_GAMES VALUES ('5','2002-05-05','1','2');
INSERT INTO TBL_GAMES VALUES ('6','2002-05-09','3','4');
INSERT INTO TBL_GAMES VALUES ('7','2002-05-10','2','3');
INSERT INTO TBL_GAMES VALUES ('8','2002-05-11','1','4');
INSERT INTO TBL_GAMES VALUES ('9','2002-05-12','2','3');
INSERT INTO TBL_GAMES VALUES ('10','2002-05-15','1','4');
 ---TBl_SCORES Datas
INSERT INTO TBl_SCORES VALUES ('1','1','66','LOSE'); 
INSERT INTO TBl_SCORES VALUES ('2','3','78','WIN');
INSERT INTO TBl_SCORES VALUES ('3','1','45','LOSE');
INSERT INTO TBl_SCORES VALUES ('4','2','56','LOSE');
INSERT INTO TBl_SCORES VALUES ('5','1','100','WIN');
INSERT INTO TBl_SCORES VALUES ('6','3','67','LOSE');
INSERT INTO TBl_SCORES VALUES ('7','2','57','LOSE');
INSERT INTO TBl_SCORES VALUES ('8','1','98','WIN');
INSERT INTO TBl_SCORES VALUES ('9','2','56','LOSE');
INSERT INTO TBl_SCORES VALUES ('10','1','46','LOSE');

INSERT INTO TBl_SCORES VALUES ('1','2','75','WIN');
INSERT INTO TBl_SCORES VALUES ('2','4','46','LOSE');
INSERT INTO TBl_SCORES VALUES ('3','3','87','WIN');
INSERT INTO TBl_SCORES VALUES ('4','4','99','WIN');
INSERT INTO TBl_SCORES VALUES ('5','2','88','LOSE');
INSERT INTO TBl_SCORES VALUES ('6','4','77','WIN');
INSERT INTO TBl_SCORES VALUES ('7','3','87','WIN');
INSERT INTO TBl_SCORES VALUES ('8','4','56','LOSE');
INSERT INTO TBl_SCORES VALUES ('9','3','87','WIN');
INSERT INTO TBl_SCORES VALUES ('10','4','78','WIN')


---Querys Answers
---1.Avg Height
select avg (HEIGTH) AS AVERAGEHEIGHT from TBL_PLAYER_DATA
---2.Avg Weight
select avg (weight) AS AVERAGEWEIGHT from TBL_PLAYER_DATA

--3.Which team has scored the most points of all games?
SELECT top 1 (TEAM_ID) FROM TBl_SCORES GROUP BY TEAM_ID ORDER BY AVG(SCORE) DESC 

--4.What is the most points scored in a single game by one team?
SELECT MAX(SCORE)AS MOSTPOINT  FROM TBl_SCORES 

--5.What is the most points scored collectively by both teams in a single game?
SELECT top 1 AVG(SCORE) FROM tbl_SCORES GROUP BY GAME_ID ORDER BY AVG(SCORE) 

--6.Are there any players who are not assigned to a team?
select  PLAYER_ID,first,last from TBL_PLAYERS where TEAM_ID is null

--7.How many teams are there?
SELECT COUNT(*) AS TOTALTEAMS FROM  TBL_TEAMS

--8.How many players are there? 
SELECT COUNT(*) AS TOTALPLAYERS FROM  TBL_PLAYERS

--9.How many games were played on the 5th of May, 2012?
select COUNT (GAME_DT)from TBL_GAMES where GAME_DT>='05/05/2012'

--10.Who is the tallest player?
select top 1 PLAYER_ID from TBL_PLAYER_DATA group by PLAYER_ID order by MAX (HEIGTH) DESC;

--11.Ron Hammer received too many flagrant fouls and has been ejected. Remove his record from the database and replace him with Al Knotgood
Update TBL_PLAYERS set PLAYER_ID =11,last='KNOTGOOD',FIRST ='AL' WHERE PLAYER_ID=8;
Delete from TBL_PLAYERS where TEAM_ID IS NULL;

--12.Generate a list of all games and game dates. Also list home and guest teams for each game.
select * from TBL_GAMES


--13.Which team has the most wins?
select top 1 TEAM_ID,count(WIN_LOSE) Win from TBL_SCORES where WIN_LOSE='WIN' group by TEAM_ID order by Win desc;

--14.Which team has the most losses?
select top 1 TEAM_ID,count(WIN_LOSE) lose from TBL_SCORES where WIN_LOSE='LOSE' group by TEAM_ID order by lose desc;

--15.Which team has the highest average score per game?
 select top 1 TEAM_ID ,avg(SCORE) average from TBL_SCORES group by TEAM_ID order by max(SCORE) asc;

--16.Generate a report that shows each team's record. Sort the report by teams with the most wins, and then by teams with the least losses.
   select * from TBl_SCORES

--17.What was the final score of each game?
select GAME_ID,sum(SCORE) from TBL_Scores group by GAME_ID;













