use dharman
drop table tbl_workers.tbl_wrk

Create schema tbl_Practice_views


create table tbl_Practice_views.tbl_employees(
Id int constraint pk_tbl_employees_Id primary key ,
EmployeeName varchar (50) not null,
Gender varchar (10) not null,
MobileNumber int not null,
Location varchar (20) not null,
Department varchar (20) not null,
)
alter table tbl_Practice_views.tbl_employees alter column Department varchar (20)  null


insert tbl_Practice_views.tbl_employees values 
(2110,'Aravind','Male',6381989950,'Tambaram','Mechanical'),
(2111,'Sadham Husian','Male',9789542563,'Cmbt','Ece'),
(2112,'Praveen','Male',9729542563,'Omr','Civil')

select * from tbl_Practice_views.tbl_employees 

create view tbl_emploeesview
as select id,EmployeeName,Department from tbl_Practice_views.tbl_employees

select Id,EmployeeName as Name  from tbl_emploeesview

insert tbl_emploeesview  values (2115,'Aamir','Ise')

