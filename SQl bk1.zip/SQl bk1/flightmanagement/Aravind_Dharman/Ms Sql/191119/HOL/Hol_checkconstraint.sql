use dharman 

Create table tbl_datetest(id int constraint pk_tbl_datetest_id primary key ,
StartDate date ,Enddate date, 
constraint ck_tbl_datetest_enddate check( Enddate>StartDate))

drop table tbl_datetest

insert tbl_datetest values (2,'08/10/2019','08/12/2019')
select * from tbl_datetest