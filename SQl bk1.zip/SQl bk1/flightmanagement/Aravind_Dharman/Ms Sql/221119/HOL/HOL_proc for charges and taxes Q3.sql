 drop proc usp_calculate_flight_payment
create proc usp8_calculate_flight_payment @in_Flight_Booking_id int,
 @out_Adult_Charges int out, @out_Child_Charges int out,
@out_total_tax_amount decimal out 
as 
begin
select  @out_Adult_Charges=(b.adult_fare)*a.no_of_adults from tbl_flight_booking a join tbl_flight b on a.flight_no=b.flight_no where booking_id=@in_Flight_Booking_id;
select @out_Child_Charges=(b.child_fare)*a.no_of_children from tbl_flight_booking a join tbl_flight b on a.flight_no=b.flight_no where booking_id=@in_Flight_Booking_id;
set @out_total_tax_amount=@out_Adult_Charges + @out_Child_Charges;
end

declare @result int,@result1 int,@result2 decimal
exec usp8_calculate_flight_payment '111',@result out,@result1 out,@result2 out
print @result
print @result1
print @result2