


-----------------FLight Management to check the next Booking id------------------------

Create PROCEDURE flight_project.proc_gen_next_flight_booking_id(@booking_id NVARCHAR(10) out)
AS
BEGIN
	SET NOCOUNT ON;
	DECLARE @BOOK_ID INT,
	@booking_id int ,@booking_id_count int

select @booking_id_count=(Count(booking_id)) from tbl_flight_booking
if (@booking_id_count=0)

print 'F100'
else
	 select @BOOK_ID=max(booking_id)+1 from tbl_flight_booking
	 SELECT @booking_id=CONCAT('F',@BOOK_ID)
end

 
