use dharman 

---table memeber 
Create table tbl_Members(
Member_Id Numeric(5) constraint pk_tbl_member_Member_id primary key ,
Member_Name Char(25),
Acc_Open_Date Datetime,
Max_Books_Allowed Numeric (2),
Penalty_Amount Numeric(7,2))


create table tbl_Book(Book_no int constraint  pk_tbl_book_book_no primary key,
Book_Name varchar(30),
author char(30),
Cost Numeric(7,2),
Category char(30))


--- create table Issue

Create table tbl_book_Issue(Lib_issue_id int constraint Pk_tbl_book_issue_lib_issues_no  primary key ,
Book_no int constraint fk_tbl_book_issue_Book_no foreign key references tbl_Book(Book_no) ,
Member_id numeric(5)  constraint fk_tbl_Book_Memberid foreign key references tbl_Members(Member_id) ,
Issue_date datetime,
Return_date datetime)


---insert into table 1

insert tbl_members  (Member_id,Member_Name,Acc_Open_Date,Max_Books_Allowed)values(2110,'Aamir Sheriff','12/10/2002',10)
insert tbl_members  (Member_id,Member_Name,Acc_Open_Date,Max_Books_Allowed)values(2115,'Sadham Husian','10/05/2003',5)
insert tbl_members  (Member_id,Member_Name,Acc_Open_Date,Max_Books_Allowed)values(2111,'Dharma Veeran','05/05/2006',6)
insert tbl_members  (Member_id,Member_Name,Acc_Open_Date,Max_Books_Allowed)values(2112,'Akil Akkinee ','09/13/2006',8)
insert tbl_members  (Member_id,Member_Name,Acc_Open_Date,Max_Books_Allowed)values(2113,'Venkatsh','11/06/2005',9)
insert tbl_members  (Member_id,Member_Name,Acc_Open_Date,Max_Books_Allowed)values(2114,'Saravana kumar','08/07/2008',15)



update tbl_members set penalty_amount=0  where member_id=2115

---insert tbl 2 

insert tbl_Book values (101,'Sql Server','Loni',200,'D')
insert tbl_Book values (102,'OOPs','Loni',600,'D')
insert tbl_Book values (103,'Principle of Laws','Issaic Newton',500,'S')
insert tbl_Book values (104,'Harry Potter','J.K.Rowling',5000,'F')
insert tbl_Book values (105,'POM','Denis Ritchie',400,'M')




insert tbl_book_Issue values (201,105,2115,'01/24/2012','02/12/2012')
insert tbl_book_Issue values (202,101,2114,'08/10/2008','08/25/2008')
insert tbl_book_Issue values (203,104,2113,'11/14/2005','11/18/2005')
insert tbl_book_Issue values (204,103,2112,'09/24/2006','10/12/2006')
insert tbl_book_Issue values (205,102,2111,'10/05/2003','10/12/2003')
insert tbl_book_Issue values (206,104,2110,'01/10/2003','02/10/2003')


update tbl_book set category='Science' where author='Issaic Newton'

select * from tbl_members
select * from tbl_Book
select * from tbl_book_Issue
----question 1
select * from tbl_members where datepart(yyyy,acc_open_date)=2006
----question 2
select * from tbl_Book where author='loni' and cost < 600
----question 3
select * from tbl_book_Issue where return_date is null
----question 4
update tbl_book_Issue set Issue_date = '02/20/2010' where return_date is null or datepart(yyyy,return_date) not in  (2011,2010)
----question 5
select * from tbl_book_Issue  where  datediff(dd,issue_date,return_date) >30
select * , datediff(dd,issue_date,return_date) from tbl_book_Issue 
----question 6
select * from tbl_Book where Category='D' and cost between 500 and 750
----question 7
select * from tbl_Book where category in ('S','D','F','M')
----question 8
select * from tbl_members order by Penalty_Amount desc
----question 9
select * from tbl_book order by category asc ,cost desc
----question 10
select * from tbl_book where book_name like '%sql%'
----question 11
select * from tbl_members where (member_name like 'a%'  or member_name like 's') and Member_Name like '%I%' 
----question 12
select concat(upper(substring(book_name,1,1)) , substring(book_name,2,len(book_name)))  book_name ,upper(author) AuthorName from tbl_book 
----question 13
select book_no , 'written by ' as '------------- ',author from tbl_Book
select concat (convert(varchar (20),Book_no ) + '    ' + 'Written by '+   '   ' , author)  from tbl_book
----question 14
select *,format(issue_date,'dddd,MMMM,dd,yyyy') issues_Date,format(Return_date,'dddd,MMMM,dd,yyyy') returndate from tbl_book_Issue where member_id=2114
----question 15
select * ,case 
when Category = 'Database' then 'D'
 when category = 'Science' then 'S'
 else 'O'
 end
 category
 from tbl_Book
----question 16
 select replace(Book_Name,' ','*'),replace(author ,' ','*') from tbl_book
----question 17
select lib_issue_id ,issue_date,return_date ,datediff(dd,issue_date,return_date) from tbl_book_Issue
----question 18
select * from tbl_members order by Acc_open_Date desc
----question 19
select * from tbl_book_Issue
select count(*) from tbl_Book_issue where Book_no= 104
----question 20
select sum(penalty_amount)  totalpenalty from tbl_members 
----question 21
select sum(cost) from tbl_book where category='database'
select * from tbl_book
----question 22
select top 1 * from tbl_book order by cost asc 
----question 23
select top 1 * from tbl_book_issue order by issue_date  asc
----question 24
select top 1 * from tbl_book_issue order by issue_date  desc
----question 25
select avg(cost)  as averageprice_of_books from tbl_book where category='database'