create table  Tbl_employee
(empid int constraint pk_Tbl_employee_empid  primary key,name varchar(20),salary nvarchar(20), 
managerid  int constraint fk_Tbl_employee_managerid  foreign key references Tbl_employee (empid))
drop table Tbl_employee
insert Tbl_employee (empid,name,salary) values (3373,'Venkat',15000)

insert Tbl_employee (empid,name,salary) values (3369,'veniladevi',15000)
insert Tbl_employee (empid,name,salary) values (3336,'Dhivya',15000)
insert Tbl_employee (empid,name,salary) values (3372,'Harish',15000)
insert Tbl_employee (empid,name,salary) values (3352,'Muthu',15000)
insert Tbl_employee (empid,name,salary) values (3353,'Balaji',15000)
insert Tbl_employee (empid,name,salary) values (3350,'Saravanan',15000)
insert Tbl_employee (empid,name,salary) values (3349,'Bharani',15000)
insert Tbl_employee (empid,name,salary) values (1234,'Venkat.A',52000)
insert Tbl_employee (empid,name,salary) values (4567,'Bidhya',25000)
insert Tbl_employee (empid,name,salary) values (2,'mts',65000)
insert Tbl_employee (empid,name,salary) values (648,'Balaji',15000)
insert Tbl_employee (empid,name,salary) values (100,'Saravanan',25000)

update  Tbl_employee set managerid=648 where empid in
select * from Tbl_employee
select t1.name as empname ,t2.name as managername from Tbl_employee t1 join Tbl_employee t2  on t1.managerid = t2.empid

SELECT CONCAT(T1.EMP_NAME,' ','  Reports to  ',' ',T2.EMP_NAME) REPORT 
FROM training.tbl_emp T1 join training.tbl_emp T2 on T1.Manager_id=T2.EMP_ID

select concat(t1.name,'','reports to ',' ' ,t2.name) report from Tbl_employee t1 join Tbl_employee t2  on t1.managerid = t2.empid