use dharman

create table tbl_ChannelCatego74120ry(
CategoryId char(1) constraint pk_tbl_ChannelCategory_categoryid primary key ,
Channel varchar (30) , 
)
insert tbl_ChannelCategory values ('A','SPORTS')
insert tbl_ChannelCategory values ('B','MOVIES')
insert tbl_ChannelCategory values ('C','MUSIC')
insert tbl_ChannelCategory values ('D','ENTERTINAMENT')

SELECT * FROM tbl_ChannelCategory
CREATE TABLE Tbl_Channels(ChannelID INT CONSTRAINT pk_Tbl_Channels_channelid primary key,
CategoryId char(1) constraint fk_Tbl_Channels_CategoryId references tbl_ChannelCategory(CategoryId),
Channelname varchar(30))
insert Tbl_Channels values(1,'A','Starsports') 
insert Tbl_Channels values(2,'A','Espn') 
insert Tbl_Channels values(3,'B','Hbo') 
insert Tbl_Channels values(4,'B','MoviesNow') 
insert Tbl_Channels values(5,'C','Mtv') 
insert Tbl_Channels values(6,'C','9Xm') 
insert Tbl_Channels values(7,'D','Sony') 
insert Tbl_Channels values(8,'D','Colors') 
select * from Tbl_Channels
create table Tbl_Programme(
Programmeid int constraint pk_tbl_programme_programme primary key,
Channelid int constraint fk_tbl_programme_channelid foreign key references Tbl_Channels(ChannelID),
ProgrammeName varchar (30) )

insert Tbl_Programme values (101,1,'SportsCenter')
insert Tbl_Programme values (102,2,'Ace')
insert c values (103,3,'Kingkong')
insert Tbl_Programme values (104,4,'Terminator')
insert Tbl_Programme values (105,5,'Roadies')
insert Tbl_Programme values (106,6,'Remix')
insert Tbl_Programme values (107,7,'Comedy Circus')
insert Tbl_Programme values (108,8,'Mahadev')
select * from Tbl_programme

create  Table Tbl_Viewers(Viewerid int , 
Programmeid int constraint  fk_tbl_viewers_programmeid Foreign key References Tbl_Programme(Programmeid),
Viewername varchar(30))
insert Tbl_Viewers values(1001,101,'Rohit')
insert Tbl_Viewers values(1002,102,'Akash')
insert Tbl_Viewers values(1003,103,'Vicky')
insert Tbl_Viewers values(1004,104,'Ajay')
insert Tbl_Viewers values(1005,105,'Vishal')
insert Tbl_Viewers values(1006,102,'Mohit')
insert Tbl_Viewers values(1006,106,'Mohit')
insert Tbl_Viewers values(1007,101,'Nakul')
insert Tbl_Viewers values(1007,107,'Nakul')
insert Tbl_Viewers values(1008,108,'Himanush')
select * from tbl_ChannelCategory
select * from Tbl_Channels
select * from Tbl_Programme
select * from Tbl_Viewers


---------------Channel to join Multiple tables----------------------------
select t1.CategoryId,t2.Channelname,t4.Viewername from  
tbl_ChannelCategory t1  join Tbl_Channels t2 on t1.CategoryId=t2.CategoryId
join Tbl_Programme t3 on t3.channelid=t2.channelid 
join Tbl_Viewers t4 on t4.Programmeid=t3.Programmeid
where Channel not in ('SPORTS','MOVIES')


