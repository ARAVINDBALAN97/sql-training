-----------------------------fn check the next payment id ---------------------------

select * from Vehicle_management.tbl_City
select * from Vehicle_management.tbl_Customer
select * from Vehicle_management.tbl_Vehicle_Payment
select * from Vehicle_management.tbl_Vehicle_Booking
select * from Vehicle_management.tbl_Vehicle_Details
select * from Vehicle_management.tbl_Customer_Discounts
 
----------------------------------function to check the net payment id --------------------------------
create function ufn_show_the_next_paymentid ()
returns varchar (20)
as
begin
declare @next_payment_id nvarchar (30),@payment_id_countnone nvarchar

select @payment_id_countnone=(count(paymentid)) from Vehicle_management.tbl_Vehicle_Payment

if (@payment_id_countnone=0)

select @next_payment_id='P600'

else

select @next_payment_id=concat( 'P' , max(paymentid) + 1) from  Vehicle_management.tbl_Vehicle_Payment

return @next_payment_id

end

select dbo.ufn_show_the_next_paymentid ()

-----------------------------trigger to update the discount value------------------------------------------

create trigger udtrg_update_customer_discount1 on Vehicle_management.tbl_Vehicle_Payment
after insert
as
begin
declare @bookingid int ,@DiscountAvaliable tinyint ,@customerid int,@dateofbooking datetime

select @bookingid=bookingid ,@DiscountAvaliable=Discountavailable from inserted

select @customerid=customer_id,@dateofbooking=dateofbooking from Vehicle_management.tbl_Vehicle_Booking where booking_id =@bookingid

if (@DiscountAvaliable=1)

    insert Vehicle_management.tbl_Customer_Discounts values (@bookingid,@customerid,@dateofbooking)

else 
    print 'Not discount Avaliable'

end

-----------------------------------------2-------------------------
--create trigger upt_insert_value_payment_discount on Vehicle_management.tbl_Vehicle_Booking 
--after insert
--as
--begin


--declare @Booking_id int ,@Customer_id int ,@DateofBooking datetime,@DiscountAvaliable tinyint,@journeydate datetime,@journeyEnd datetime,@RatetaxperDay decimal  (8,5)

--select @Booking_id=Booking_Id , @Customer_id=customer_id,@DateofBooking=DateofBooking from inserted

--select @Customer_id=(count(Customer_Id)),@DateofBooking=DateofBooking,@Booking_id=Booking_Id from Vehicle_management.tbl_Vehicle_Booking where Customer_Id =@Customer_id

--if(@Customer_id>=3)

--     insert into Vehicle_management.tbl_Vehicle_Payment  (@Booking_id,@DateofBooking,)




--end


----------------------------------procedure------------------------------------------------------

select * from Vehicle_management.tbl_City
select * from Vehicle_management.tbl_Customer
select * from Vehicle_management.tbl_Vehicle_Payment
select * from Vehicle_management.tbl_Vehicle_Details
select * from Vehicle_management.tbl_Customer_Discounts
select * from Vehicle_management.tbl_Vehicle_Booking


create procedure usp_proc_tocheck_vehicle_Availibity (@vechileType varchar (30),@Location varchar (20),
@Journeystartdate datetime,
@journeyenddate datetime,
@out_status  int out)
as
begin

declare @enddate datetime

set nocount on;

select top 2 @enddate=(min (JourneyEndDate))  from Vehicle_management.tbl_Vehicle_Booking where VehicleType=@vechileType and location=@Location group by vehicletype

if (@enddate < @Journeystartdate)
set @out_status=1
else 
set @out_status=0
return @out_status
end


declare @out_status int 
exec usp_proc_tocheck_vehicle_Availibity  'Benz','204','11/28/2019','11/29/2019',@out_status out
print @out_status



-------------------------------------procedure to insert the values-----------------------

create procedure uso_insert_values_by_avaliable_vehicle (@customer_id int,@Vehicletype varchar (20),
@traveltype varchar (20),@address varchar (50),@location varchar (20),
@DateofBooking datetime,@journeystartdate datetime,
@journeystarttime decimal (4,2),@journeyenddate datetime,
@journeyendtime decimal(4,2),@out_status int  out,@out_booking_id int out )
as
begin
declare @enddate datetime,@bookingid int
    select @enddate=(min(JourneyEndDate)) from Vehicle_management.tbl_Vehicle_Booking where vehicletype=@Vehicletype and Location=@location group by vehicletype
	if (@enddate<@journeystartdate)
	begin
	insert into Vehicle_management.tbl_Vehicle_Booking  values (@customer_id,@Vehicletype,@traveltype,@address,@location,@dateofbooking,@journeystartdate,@journeystarttime,@journeyEnddate,@journeyEndtime)
	 select top 1 @bookingid=Booking_id from Vehicle_management.tbl_Vehicle_Booking order by  booking_id desc
	 set @out_status=1
	 set @out_booking_id=@bookingid
	 end
	 else
	 begin
	  set @out_status=0
	  set @out_booking_id=0
	  end

	 
end

declare @out_status int ,@out_booking_id int
exec uso_insert_values_by_avaliable_vehicle 105,'Tata sumo','travel','Madurai','200','11/29/2019','12/02/2019',19.00,'01/06/2020',13.00,@out_status out,@out_booking_id out
 print @out_booking_id
print @out_status