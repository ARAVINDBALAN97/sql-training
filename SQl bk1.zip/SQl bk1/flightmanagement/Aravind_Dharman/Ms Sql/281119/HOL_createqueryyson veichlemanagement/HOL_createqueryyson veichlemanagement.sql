create schema Vehicle_management
create table Vehicle_management.tbl_City (CityCode	Varchar(3) constraint pk_tbl_city_citycode PRIMARY KEY ,
CityName Varchar(50)UNIQUE);

insert Vehicle_management.tbl_City values (200,'Chennai')
insert Vehicle_management.tbl_City values(201,'Kanchipuram')
insert Vehicle_management.tbl_City values(202,'Madurai')
insert Vehicle_management.tbl_City values(203,'Kovai')
insert Vehicle_management.tbl_City values(204,'Thirunalveli')
insert Vehicle_management.tbl_City values(205,'Villupuram')
insert Vehicle_management.tbl_City values(206,'Krishnagiri')



------------------------------------------------------------------------------------------------------------------------------------------
create table Vehicle_management.tbl_Customer(CustomerId Int constraint  pk_tbl_Customer_CustomerId PRIMARY KEY identity(100,1) ,FirstName	Varchar(50)NOT NULL,LastName Varchar(50)NOT NULL,
Address	Varchar(50)NOT NULL,Email Varchar(50) UNIQUE NOT NULL,Phone varchar(10)NOT NULL)

insert Vehicle_management.tbl_Customer values('Sadham','Husian','kanchipuram','Sadhamhusain@gmail.com','9789271488')
insert Vehicle_management.tbl_Customer values('Aamir','Sherif','Vellore','aamirsheriff@gmail.com','9875641238')
insert Vehicle_management.tbl_Customer values('Dharma','veeran','Erode','dharmaveeera@gmail.com','8248055170')
insert Vehicle_management.tbl_Customer values('Muthu','Kumar','madurai','muthukumar@gmail.com','8147056236')
insert Vehicle_management.tbl_Customer values('Akil','Akkinee','Chennai','akilakkineen@gmail.com','896589563')
insert Vehicle_management.tbl_Customer values('Harish','Paupaleti','Trichy','HarishPaupaleti@gmail.com','236589562')
-----------------------------------------------------------------------------------------------
create table Vehicle_management.tbl_Vehicle_Details (
VehicleType	Varchar(10),	
Location	Varchar(3)constraint fk_tbl_Vehicle_Details_Location Foreign key REFERENCES Vehicle_management.tbl_City(CityCode),
NoOfVehicles	Int	check(NoOfVehicles>0),
RatePerDay	Int	check(RatePerDay>0),
Tax	Decimal(4,2)	,
constraint pk_tbl_Vehicle_Details_Primary_VehicleType_Location primary Key(VehicleType,Location))

insert Vehicle_management.tbl_Vehicle_Details values ('Tavera',201,3,1000,25)
insert Vehicle_management.tbl_Vehicle_Details values ('Tata Sumo',200,2,800,15)
insert Vehicle_management.tbl_Vehicle_Details values ('Scorpio',203,5,2000,50.00)
insert Vehicle_management.tbl_Vehicle_Details values ('Benz',204,6,2500,40.00)
insert Vehicle_management.tbl_Vehicle_Details values ('Rolls Roys',205,1,10000,45.00)
insert Vehicle_management.tbl_Vehicle_Details values ('Innova',206,3,2850,10.00)
insert Vehicle_management.tbl_Vehicle_Details values ('Audi',202,2,3000,25.00)






----------------------------------------------------------------------------------
create table Vehicle_management.tbl_Vehicle_Booking 
(Booking_Id	Int constraint 	pk_tbl_Vehicle_Booking_Booking_Id Primary Key Identity(200,1),
Customer_Id	Int	 constraint fk_tbl_Vehicle_Booking_Customer_Id FOREIGN KEY REFERENCES Vehicle_management.tbl_Customer(CustomerId),
VehicleType	Varchar(10)	,
TravelType	Varchar(10)	check(TravelType IN('Travel','Day','Drop')),
Address	Varchar(30),	
Location	Varchar(3)	constraint fk_tbl_Vehicle_Booking_Location FOREIGN KEY REFERENCES Vehicle_management.tbl_City(CityCode),
DateOfBooking	DateTime NOT NULL,	
JourneyStartDate	DateTime	NOT NULL,
JourneyStartTime	decimal (4,2),	
JourneyEndDate	DateTime	NOT NULL,
JourneyEndTime	Decimal(4,2) NOT NULL,	
check(JourneyStartDate>=DateOfBooking),check(JourneyEndDate>=JourneyStartDate),
constraint fk_tbl_Vehicle_VehicleType_Location FOREIGN Key(VehicleType,Location) REFERENCES Vehicle_management.tbl_Vehicle_Details(VehicleType,Location))


select * from Vehicle_management.tbl_City
select * from Vehicle_management.tbl_Vehicle_Details
select * from Vehicle_management.tbl_Vehicle_Booking 
select * from Vehicle_management.tbl_Customer
insert Vehicle_management.tbl_Vehicle_Booking  values (101,'Audi','Day','Kaveripattinam','202','11/28/2019','11/29/2019',13.00,'11/30/2019',00.00)
insert Vehicle_management.tbl_Vehicle_Booking  values (102,'Benz','Drop','kanchipuram','204','11/28/2019','11/28/2019',11.00,'11/28/2019',12.00)
insert Vehicle_management.tbl_Vehicle_Booking  values (103,'Rolls Roys','Day','Vellore','205','11/28/2019','11/28/2019',8.00,'11/29/2019',8.00)
insert Vehicle_management.tbl_Vehicle_Booking  values (104,'scorpio','Travel','Erode','203','11/28/2019','11/30/2019',08.00,'12/02/2019',16.00)
insert Vehicle_management.tbl_Vehicle_Booking  values (105,'Tavera','Travel','Krishnangiri','201','11/28/2019','11/29/2019',02.00,'11/30/2019',13.00)
insert Vehicle_management.tbl_Vehicle_Booking  values (106,'Tata sumo','Travel','Madurai','200','11/28/2019','12/03/2019',08.00,'12/06/2019',15.00)


insert Vehicle_management.tbl_Vehicle_Booking  values (101,'Innova','Travel','Chennai','206','11/30/2019','12/01/2019',12.00,'12/03/2019',1.00)
insert Vehicle_management.tbl_Vehicle_Booking  values (103,'Rolls Roys','Travel','Erode','205','12/01/2019','12/12/2019',13.00,'12/14/2019',16.00)








--------------------------------------------------------------------------------------
create table Vehicle_management.tbl_Customer_Discounts(Booking_Id Int	constraint fk_tbl_Customer_Discounts_BookingId FOREIGN  KEY REFERENCES Vehicle_management.tbl_Vehicle_Booking(Booking_Id),
CustomerId	Int	FOREIGN KEY REFERENCES Vehicle_management.tbl_Customer(CustomerId),
DateOfAvailing	DateTime	
)

drop table Vehicle_management.tbl_Customer_Discounts

---------------------------------------------------------------------------------------------
create table  Vehicle_management.tbl_Vehicle_Discounts(VehicleType	Varchar(10)	,
Location	Varchar(3)	,
NoOfTimes	Int	,
Discount	Decimal(4,2),	
constraint fk_tbl_Vehicle_Discounts_VehicleType_Location FOREIGN Key(VehicleType,Location) REFERENCES Vehicle_management.tbl_Vehicle_Details(VehicleType,Location))

drop table Vehicle_management.tbl_Vehicle_Discounts



-------------------------------------------------------------------------------------------------
create table Vehicle_management.tbl_Vehicle_Payment(PaymentId	int constraint	pk_tbl_Vehicle_Payment_PaymentId Primary Key identity (600,1),
BookingId	Int	constraint fk_tbl_Vehicle_Payment_BookingId FOREIGN KEY REFERENCES Vehicle_management.tbl_Vehicle_Booking(Booking_Id),
TotalCharges	Int	,
TotalTaxAmount	Decimal(7,2),	
DiscountAvailable	tinyint check (DiscountAvailable=0 or DiscountAvailable=1 ))


insert into Vehicle_management.tbl_Vehicle_Payment values(600,214,8550,30.00,1)
insert into Vehicle_management.tbl_Vehicle_Payment values(601,205,11400,40,0)
insert into Vehicle_management.tbl_Vehicle_Payment values(602,216,20000,90,1)
insert into Vehicle_management.tbl_Vehicle_Payment values(603,210,2000,25,0)

drop  table Vehicle_management.tbl_Vehicle_Payment

