alter function ufn_Seat_Available(@flight_no int,@DateOfJourney datetime, @NoOfAdults int, @NoOfChildren int)
returns int
as
begin
Declare @availabls int
Declare @Totalseats int
declare @Bookedseats int
declare @given_seats int
set @given_seats=@NoOfAdults+@NoOfChildren
select @Bookedseats =(select sum(cast( total_seats_booking as int )) as total from  tbl_flight_booking where flight_no=@flight_no and Date_Of_Journey=@DateOfJourney)
select @Totalseats=(SELECT Total_seats FROM TBL_FLIGHT where flight_no = @flight_no)
 set @availabls=@Totalseats- @Bookedseats
 declare @i int
if((@availabls<@Totalseats) and ( @given_seats<=@availabls))
set @i=1
else
set @i=0
return @i
end