create function ufn_Seatstest1_Availability(@flight_no int)
returns int
as
begin
Declare @availabls int
Declare @Totalseats int
declare @Bookedseats int
select @Bookedseats =(select sum(cast( total_seats_booking as int )) as total from  tbl_flight_booking where flight_no=@flight_no)
select @Totalseats=(SELECT Total_seats FROM TBL_FLIGHT where flight_no = @flight_no)
 set @availabls=@Totalseats- @Bookedseats
 return @availabls
end