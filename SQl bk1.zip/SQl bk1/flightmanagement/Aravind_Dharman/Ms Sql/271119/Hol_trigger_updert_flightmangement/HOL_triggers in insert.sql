create trigger ust_Flight_booking on tbl_flight_booking
 after insert 
 as begin
 declare @total_seats_booking int,@Current_Avbl_seats int, @New_avbl_seats int,@flight_no int

  select @total_seats_booking=total_seats_booking,@flight_no=flight_no from inserted 

-- select @total_seats_booked =(select sum(cast( total_seats_booking as int )) as total from  tbl_flight_booking where flight_no=@flight_no)
 select @Current_Avbl_seats =( select Remainingseats from tbl_FlightSeat_Status where flightno=@flight_no)
 --select @Totalseats_capacity=(SELECT Total_seats FROM TBL_FLIGHT where flight_no = @flight_no)
 set @New_avbl_seats=@Current_Avbl_seats-@total_seats_booking
 update tbl_FlightSeat_Status set Remainingseats =@New_avbl_seats where flightno = @flight_no
 end