select * from tbl_flight
select * from tbl_flightseat_status
select * from tbl_flight_booking
select * from tbl_flight_payment
------------------------TRIGGER FOR INSERT THE DATA-------------------------------------------------------------
create trigger ust_Flight_booking_a1 on  tbl_flight_booking
after insert
as
begin
declare @avail_seats_in_t3 int,@totalseat_booking_in_t2 int ,@total_avail_seats_booking int , @flight_no int

select @totalseat_booking_in_t2=Total_seats_Booking ,@flight_no=flight_no from inserted

select @avail_seats_in_t3=(select remainingseats from tbl_flightseat_status where FlightNo=@flight_no)

set @total_avail_seats_booking=@avail_seats_in_t3-@totalseat_booking_in_t2

update tbl_flightseat_status set Remainingseats=@total_avail_seats_booking where flightno=@flight_no
end

------------------------TRIGGER FOR DELETE THE DATA------------------------------------------------------

create trigger ust_flight_booking_del1 on tbl_flight_booking
after delete
as
begin
declare @avail_seats_in_t3 int,@totalseat_booking_in_t2 int,@total_avail_seat_booking int ,@flight_no int

select @totalseat_booking_in_t2=Total_seats_Booking from deleted

select @avail_seats_in_t3=(select Remainingseats from tbl_flightseat_status where flightno=@flight_no)

set @total_avail_seat_booking = @avail_seats_in_t3+@totalseat_booking_in_t2

update tbl_flightseat_status set Remainingseats=@total_avail_seat_booking where flightno=@flight_no
end

------------------------TRIGGER FOR UPDATE THE DATA------------------------------------------------------

create trigger ust_flight_booking_up1 on tbl_flight_booking
after update 
as
begin
declare @avail_seats_in_t3 int,@totalseat_booking_in_t2 int,@total_avail_seat_booking int,@total_deleted_seats int  ,@flight_no int

select @totalseat_booking_in_t2=Total_seats_Booking ,@flight_no=flightno from inserted

select @total_deleted_seats=Total_seats_Booking ,@flight_no=flightno from deleted

select @avail_seats_in_t3=(select Remainingseats from tbl_flightseat_status where flightno=@flight_no)

set @total_avail_seat_booking=(@avail_seats_in_t3+@total_deleted_seats)-@totalseat_booking_in_t2

update tbl_flightseat_status set Remainingseats=@total_avail_seat_booking where flightno=@flight_no
end


INSERT TBL_FLIGHT_BOOKING VALUES (508,100,'09/02/2019','12/08/2019',5,1,'6')
INSERT TBL_FLIGHT_BOOKING VALUES (506,101,'09/02/2019','12/08/2019',5,5,'10')
INSERT TBL_FLIGHT_BOOKING VALUES (505,100,'09/02/2019','12/08/2019',5,6,'11')
INSERT TBL_FLIGHT_BOOKING VALUES (508,100,'09/02/2019','12/08/2019',5,3,'8')
INSERT TBL_FLIGHT_BOOKING VALUES (505,100,'09/02/2019','12/08/2019',5,2,'7')
INSERT TBL_FLIGHT_BOOKING VALUES (505,100,'09/02/2019','12/08/2019',5,5,'10')
INSERT TBL_FLIGHT_BOOKING VALUES (505,100,'09/02/2019','12/08/2019',5,1,'6')
INSERT TBL_FLIGHT_BOOKING VALUES (506,100,'09/02/2019','12/08/2019',5,1,'6')
INSERT TBL_FLIGHT_BOOKING VALUES (508,100,'09/02/2019','12/08/2019',5,3,'8')
INSERT TBL_FLIGHT_BOOKING VALUES (508,101,'09/02/2019','12/08/2019',5,4,'9')
INSERT TBL_FLIGHT_BOOKING VALUES (506,101,'09/02/2019','12/08/2019',5,1,'6')
INSERT TBL_FLIGHT_BOOKING VALUES (505,101,'09/02/2019','12/08/2019',5,2,'7')
INSERT TBL_FLIGHT_BOOKING VALUES (508,101,'09/02/2019','12/08/2019',5,0,'5')
INSERT TBL_FLIGHT_BOOKING VALUES (505,101,'09/02/2019','12/08/2019',2,0,'2')
INSERT TBL_FLIGHT_BOOKING VALUES (505,101,'09/02/2019','12/08/2019',1,0,'1')
INSERT TBL_FLIGHT_BOOKING VALUES (506,101,'09/02/2019','12/08/2019',6,0,'6')
INSERT TBL_FLIGHT_BOOKING VALUES (505,101,'09/02/2019','12/08/2019',2,0,'6')
INSERT TBL_FLIGHT_BOOKING VALUES (505,101,'09/02/2019','12/08/2019',2,0,'6')
INSERT TBL_FLIGHT_BOOKING VALUES (508,100,'09/02/2019','12/08/2019',3,1,'4')
INSERT TBL_FLIGHT_BOOKING VALUES (506,100,'09/02/2019','12/08/2019',5,1,'6')
INSERT TBL_FLIGHT_BOOKING VALUES (505,101,'09/02/2019','12/08/2019',5,1,'6')
INSERT TBL_FLIGHT_BOOKING VALUES (508,101,'09/02/2019','12/08/2019',2,2,'4')
INSERT TBL_FLIGHT_BOOKING VALUES (505,101,'09/02/2019','12/08/2019',5,0,'5')
INSERT TBL_FLIGHT_BOOKING VALUES (505,101,'09/02/2019','12/08/2019',5,1,'6')
INSERT TBL_FLIGHT_BOOKING VALUES (505,100,'09/02/2019','12/08/2019',5,2,'7')
INSERT TBL_FLIGHT_BOOKING VALUES (508,100,'09/02/2019','12/08/2019',8,7,'15')
INSERT TBL_FLIGHT_BOOKING VALUES (506,101,'09/02/2019','12/08/2019',6,6,'12')
INSERT TBL_FLIGHT_BOOKING VALUES (505,101,'09/02/2019','12/08/2019',5,7,'12')

select cast() as total_count from TBL_FLIGHT_BOOKING 
delete from TBL_FLIGHT_BOOKING where booking_id not in (100,372,373,374) rollback

