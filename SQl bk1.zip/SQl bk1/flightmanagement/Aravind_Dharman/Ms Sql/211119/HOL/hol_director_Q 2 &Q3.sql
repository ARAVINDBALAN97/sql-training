
select * from tblActor
select * from tblDirector
select * from  tblFilm
select * from  tbllanguage


select distinct count (directorid) directorcount from tblDirector
select distinct count (ActorID) actorcount from tblactor
----------------------------------------------------------------------------------------------------'
---3.join Director name and film by desc
select top 4 a.directorid,a.DirectorName,a.DirectorDOB,b.FilmName from tblDirector a 
 join  tblFilm b on b.FilmDirectorID= a.DIRECTORID order by a.DirectorDOB desc

-----2.create a query to list out which films won oscar awards except in english language 
  select a.Filmname,a.filmlanguageid,a.filmoscarwins from tblfilm a join
  tbllanguage b on b.languageid=a.filmlanguageid 
  where b.language != 'English' and Filmoscarwins != 0;


------------------------------------------------------------------------------------------

  select T1.filmname from tblfilm T1 join tbllanguage T2 on T2.languageID =  T1.filmlanguageID 
  where FilmLanguageID in ( select LanguageID from tbllanguage where Language != 'English' ) and 
  filmoscarwins !=0
  
------------------------------------------------------------------------------------


select f.filmname from tblFilm f where f.filmdirectorid in(
select top 3 d.directorid from tbldirector d order by d.directordob desc,d.directorid asc)

