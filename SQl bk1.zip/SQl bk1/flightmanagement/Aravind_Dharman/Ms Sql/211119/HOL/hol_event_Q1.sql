select * from tblevent
select * from tblcountry

---question 1
select EventName from tblevent where Eventdate > (select  top 1 EventDate from tblevent where countryid = 5 order by EventDate desc )

