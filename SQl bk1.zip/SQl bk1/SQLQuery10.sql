use dharman

create table tbl_flight(
Flightno int constraint pk_tbl_flight_Flightno primary key identity  (500,1),
AirlinesName varchar(50),
Sourcrofflight varchar (20),
Destination varchar (20),
DepatureTime decimal (4,2),
Arrrivaltime decimal (4,2),
TotalSeats int,
AdultFare int,
ChildFare int,
Airporttax decimal(4,2)
)


--------------------------------------------------------------------
create table tbl_flight_booking(
Bookingid int constraint pk_tbl_flight_booking_Bookingid primary key identity (100,1),
FlightNo int constraint fk_tbl_flight_booking_FlightNo foreign key references tbl_flight
(Flightno) on update cascade,CustomerID int,DateofBooking datetime default getdate(),  DateofJourney datetime,
NoofAdults int,
NoofChilderns int,
Total_no_Seats int ,
Constraint Ck_Check_Doj check(Dateofjourney>=DateofBooking)
)
 
-------------------------------------------------------------------
Create table tbl_flight_seat_status(
flightno int  constraint fk_tbl_flight_seat_status_flightno foreign key references tbl_flight(Flightno)  on update cascade,
DateofJourney datetime,Avaliableseats int)



----------------------------------------------------------------------
create table tbl_Flight_Travellers(
Bookingid int constraint fk_tbl_Flight_Travellers_Bookingid foreign key references tbl_flight_booking (Bookingid) on update cascade,FirstName varchar (20),Lastname varchar (20),
Travellertype char(1))


-------------------------------------------------------------------
create table tbl_Flight_Payment(Paymentid int constraint pk_tbl_Flight_Payment_Paymentid primary key,
Bookingid int constraint fk_tbl_Flight_Payment_Bookingid foreign key references tbl_flight_booking (Bookingid)  on update cascade,
AdultCharges int ,ChildCharges int ,Taxamount decimal (7,2))
 


--------------tbl_flight-----------------
insert tbl_flight values ('AirIndia','Delhi','Chennai','12:00','5:00',150,2500,1000,500)

